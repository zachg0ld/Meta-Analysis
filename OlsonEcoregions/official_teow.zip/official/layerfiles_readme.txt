This zip file contains two layer files, terr_biomes.lyr and wwf_terr_ecos.lyr.  
You may use these layer files to symbolize by ecoregions or by biomes.